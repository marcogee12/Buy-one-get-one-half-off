﻿'Name: Lorenzo's BoGoHo Sale'
'Purpose: Calculates total sale with lower priced item being half off'
'Programmer: Marco Gomez'
'Date: 6/19/2019'

Option Infer On
Public Class Form1

    'Send the exit button the event to close the app'
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    'Calculates Buy one get one half off sale'
    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'Scoped variables for user input of price 1 and 2'
        Dim Price1 As Double = txtPrice1.Text
        Dim Price2 As Double = txtPrice2.Text

        'Saved original price to be able to calculate the total saved later on in the application'
        Dim OriginalTotal As Double = Price1 + Price2

        'Takes lower priced item and divides it by 2, if they are equal it will take price of item 1 and divide by 2'
        If Price1 <= Price2 Then
            Price1 = Price1 / 2
        Else
            Price2 = Price2 / 2
        End If

        'Calculates Total due after detecting which item will be half off and displays it as a currency'
        Dim Total As Double = Price1 + Price2
        txtTotalDue.Text = FormatCurrency(Total)

        'Takes saved original price from earlier in the app and subtracts the total due from it to calculate total amount of money saved then displays it as a currency'
        Dim TotalSaved As Double = OriginalTotal - Total
        txtSaved.Text = FormatCurrency(TotalSaved)

    End Sub
End Class
